$('li').on('click',function () {
    $(this).children().css('display','block')
})